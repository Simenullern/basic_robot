# basic_robot
School project TDT4113. Simple AI, behavior based robotics. Python coded Raspberry PI on an arduino zumo robot. 
Made by Kjetil, Vebjørn and Simen with sensor-wrapped code granted by the TDT4113-team
